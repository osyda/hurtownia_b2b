# DOSTAWIO — Identyfikacja wizualna (Kierunek „Sygnał")

Kompletna paczka logo dla **dostawio Connect** — platformy zamówień B2B dla hurtowni.
Wszystkie pliki wektorowe; tekst zamieniony na **krzywe** (niezależne od fontów).

---

## Struktura paczki

```
DOSTAWIO-Brand/
├── svg/        — wektory (WWW i druk, tekst w krzywych)
├── png/        — rastry z przezroczystością (WWW, prezentacje, social)
├── favicon/    — komplet ikon dla strony i aplikacji
└── print/      — arkusz i wytyczne dla drukarni
```

## svg/  (główne pliki robocze — skalują się bez utraty jakości)
| Plik | Zastosowanie |
|---|---|
| `logo-horizontal.svg` | **Podstawowe** logo poziome |
| `logo-vertical.svg` | Układ pionowy (wąskie przestrzenie) |
| `wordmark.svg` | Sam logotyp, bez sygnatury |
| `logo-horizontal-darkbg.svg` / `logo-vertical-darkbg.svg` | Wersja na ciemne tło (negatyw) |
| `logo-horizontal-mono.svg` / `wordmark-mono.svg` | Monochrom 1-kolor (druk czarno-biały, pieczątki, faks) |
| `icon-brand.svg` | Sygnatura „d” — wersja podstawowa |
| `icon-accent.svg` / `icon-paper.svg` / `icon-reverse.svg` | Sygnatura w wariantach kolorystycznych |
| `icon-mono.svg` | Sygnatura 1-kolor |
| `mark-open.svg` / `mark-open-white.svg` | Znak „d” bez kafla (na zdjęcia) |
| `maskable.svg` | Pełnoekranowa ikona (PWA / Android maskable) |

## png/  (przezroczyste tło)
`logo-horizontal.png` (1600 px) · `logo-horizontal@2x.png` (2400 px) · `logo-vertical.png` · `wordmark.png` · `logo-horizontal-mono.png` · `logo-horizontal-darkbg.png` · `icon-16…512.png`

## favicon/
| Plik | Gdzie wpiąć |
|---|---|
| `favicon.ico` | Klasyczny favicon (16/32/48 w jednym pliku) |
| `favicon-16/32/48.png` | Nowoczesne przeglądarki |
| `apple-touch-icon-180.png` | Ekran główny iOS |
| `maskable-512.png` | PWA / manifest (`purpose: maskable`) |

Snippet do wklejenia w `<head>` znajdziesz w `favicon/snippet.html`.

---

## Kolory

| Nazwa | HEX | RGB | CMYK | Pantone (≈) |
|---|---|---|---|---|
| Grafit | `#1D2125` | 29 · 33 · 37 | 78 · 68 · 60 · 70 | Black 6 C |
| Bursztyn | `#E08A2B` | 224 · 138 · 43 | 0 · 39 · 81 · 12 | 1385 C |
| Kość słoniowa | `#F4F1EC` | 244 · 241 · 236 | 3 · 3 · 6 · 0 | Warm Gray 1 C |
| Atrament (tła) | `#16191C` | 22 · 25 · 28 | 80 · 70 · 62 · 76 | Neutral Black C |

> Do druku używaj wartości **CMYK** (lub Pantone). Do ekranów — HEX/RGB.

## Typografia
**Sora** (Google Fonts, bezpłatny, SIL OFL). Logotyp: Bold/ExtraBold, światło liter −3%.
W logo tekst jest już w krzywych — font nie jest potrzebny do jego użycia.

## Zasady
- Zachowaj **pole ochronne** = wysokość sygnatury wokół logo.
- Minimalny rozmiar: 120 px (ekran) / 22 mm (druk); poniżej używaj samej sygnatury (min. 16 px).
- Nie rozciągaj, nie obracaj, nie przebarwiaj, nie dodawaj cieni, nie umieszczaj na niskim kontraście.

---
*dostawio — Połączenie, które napędza Twój biznes.*
